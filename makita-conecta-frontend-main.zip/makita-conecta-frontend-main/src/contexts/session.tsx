import { users } from "@/service/mocks/users";
import { createContext, useState } from "react";

type UserDTO = {
    name: string
    email:string
    password: string
}

type SessionContextProps = {
    userLogged: UserDTO | null
    signIn: (email: string, password: string) => Promise<void>
    signUp: (name: string, email: string, password: string) => Promise<void>
    signOut: () => Promise<void>
}

export const SessionContext = createContext({} as SessionContextProps)

type SessionProviderProps = {
    children: React.ReactNode
}

export function SessionProvider({children}:SessionProviderProps){
    const [userLogged, setUserLogged] = useState<UserDTO | null>(null)

    async function signIn(email: string, password: string){
        try{
            const user = users.find(user => user.email === email && user.password === password)

            if(!user){
                throw new Error("Usuário ou senha inválidos")
            }

            setUserLogged(user)
        }catch(error){            
            throw error
        }
    }

    async function signUp(name: string, email: string, password: string){
        try{
            const userExists = users.find(user => user.email === email)

            if(userExists){
                throw new Error("Esse usuário já está cadastrado")
            }

            users.push({name, email, password})

            setUserLogged({name, email, password})
        }catch(error){
           throw error
        }
    }

    async function signOut(){
        setUserLogged(null)
    }


    return (
        <SessionContext.Provider value={{userLogged, signIn, signUp, signOut}}>
            {children}
        </SessionContext.Provider>
    )
}