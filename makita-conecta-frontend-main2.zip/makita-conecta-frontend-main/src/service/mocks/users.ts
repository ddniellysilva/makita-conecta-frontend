export const users = [
    {
        name: "Danielly Silva",
        email: "danielly@email.com",
        password: "12345678"
    }
]